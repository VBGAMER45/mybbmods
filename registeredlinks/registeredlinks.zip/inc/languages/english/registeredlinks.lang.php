<?php
$l['reglinks_text'] = 'You are not allowed to view links. <a href="{bburl}/member.php?action=register">Register</a> or <a href="{bburl}/member.php?action=login">Login</a> to view.';


	
?>
