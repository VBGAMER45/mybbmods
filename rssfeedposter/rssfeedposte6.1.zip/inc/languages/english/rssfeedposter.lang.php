<?php
/*
RSS Feed Poster
Version 1.0
by:vbgamer45
http://www.mybbhacks.com
*/

// RSS Feed Poster text strings
$l['rssfeedposter_taskran'] = 'RSS Feed Poster Task Ran';


?>