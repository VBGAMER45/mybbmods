<?php

$l['mediapro_admin'] = 'Simple Audio Video Embedder';
$l['mediapro_settings'] = 'Settings';
$l['mediapro_save_settings'] = 'Save Settings';
$l['mediapro_err_cache'] = 'Cache folder not writable must fix for performance!';

$l['mediapro_txt_default_width'] = 'Default Video Player Width:';
$l['mediapro_txt_default_height'] = 'Default Video Player Height:';
$l['mediapro_txt_default_info'] = 'Use 0 to use media player defaults';
$l['mediapro_checkall'] = 'Check All';
?>
