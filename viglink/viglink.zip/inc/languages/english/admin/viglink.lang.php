<?php
$l['viglink_settings'] = 'Viglink Settings';
$l['viglink_title'] = 'Viglink Settings';

$l['viglink_options'] = 'Options';

$l['viglink_signup'] = 'Signup';

$l['viglink_whatisviglink'] = 'Viglink scans your links on your forum and adds affiliate tracking and your forum will earn a percent of any sale made from any link that a user posts';

$l['viglink_setup'] = 'Setup';

$l['viglink_setup_desc'] = 'Two ways to setup one you can enter your Viglink Api Key or you can enter the full javascript code for Viglink';

$l['viglink_apikey'] = 'Viglink Api Key';
$l['viglink_reaffiliate'] = 'Reaffiliate Links:';

$l['viglink_rawcode'] = 'Or Enter your Viglink full javascript code';


$l['viglink_savesettings'] = 'Save Settings';



?>
